package com.example

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.sin

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("main_scaffold")
                ) { innerPadding ->
                    AuraToolboxApp(
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

// Simple localization helper
fun getTxt(key: String, isArabic: Boolean): String {
    return if (isArabic) {
        when (key) {
            "app_title" -> "أورا - صندوق الأدوات"
            "tab_device" -> "الأجهزة"
            "tab_zones" -> "المواقيت"
            "tab_notes" -> "المفكرة"
            "tab_breathe" -> "التنفس"
            "tab_pinger" -> "الاتصال"
            
            // Device Screen
            "device_header" -> "مراقب الأجهزة والنظام"
            "device_sub" -> "البيانات الحية المباشرة لجهازك والبطارية"
            "battery_level" -> "مستوى البطارية"
            "battery_status" -> "حالة البطارية"
            "battery_charging" -> "جاري الشحن"
            "battery_plugged" -> "موصل بالكهرباء"
            "battery_discharging" -> "يتم الاستهلاك"
            "battery_full" -> "ممتلئة بالكامل"
            "battery_unknown" -> "غير معروقة"
            "device_info" -> "معلومات النظام"
            "sys_brand" -> "الشركة المصنعة"
            "sys_model" -> "طراز الجهاز"
            "sys_os" -> "إصدار أندرويد"
            "sys_sdk" -> "مستوى SDK"
            "sys_hardware" -> "العتاد المادي"
            "sys_display" -> "الشاشة وحجمها"
            
            // Zones Screen
            "zones_header" -> "منسق التوقيت العالمي"
            "zones_sub" -> "سافر عبر الزمن وحساب فروق التوقيت"
            "gmt_offset" -> "إزاحة الوقت اليدوية: %+d ساعة"
            "city_london" -> "لندن"
            "city_cairo" -> "القاهرة"
            "city_mecca" -> "مكة المكرمة"
            "city_tokyo" -> "طوكيو"
            "city_newyork" -> "نيويورك"
            "time_travel_title" -> "سفر بالتوقيت المخصص"
            "time_standard" -> "التوقيت الفعلي"
            
            // Notes Screen
            "notes_header" -> "المفكرة السريعة الآمنة"
            "notes_sub" -> "ملاحظاتك السريعة المخزنة محلياً بالكامل"
            "note_title" -> "عنوان الملاحظة"
            "note_content" -> "اكتب ملاحظتك السريعة هنا..."
            "note_add" -> "إضافة الملاحظة"
            "note_search" -> "ابحث في الملاحظات..."
            "note_empty" -> "لا تفوت الأفكار! مفكرتك فارغة حالياً."
            "note_deleted" -> "تم حذف الملاحظة بنجاح"
            "note_added" -> "تمت إضافة الملاحظة بنجاح"
            "note_copied" -> "تم نسخ الملاحظة إلى الحافظة"
            
            // Breathe Screen
            "breathe_header" -> "أورا - ركن التنفس والهدوء"
            "breathe_sub" -> "تمارين التنفس العميق والاسترخاء الفوري"
            "breathe_mode" -> "نمط التمرين"
            "breathe_mode_box" -> "تنفس الصندوق (4-4-4)"
            "breathe_mode_relax" -> "الاسترخاء العميق (4-7-8)"
            "breathe_mode_equal" -> "التنفس المتوازن (5-5)"
            "breathe_state_inhale" -> "شهيــــق... امتلئ طاقة"
            "breathe_state_hold" -> "احبـــس... استشعر السكون"
            "breathe_state_exhale" -> "زفيــــر... تخلص من التوتر"
            "breathe_start" -> "ابدأ تمرين التنفس"
            "breathe_customizer" -> "الموجات الصوتية التفاعلية حية بموجات Canvas"
            "audio_wave" -> "مؤثر التناغم البصري"
            
            // Connectivity Screen
            "conn_header" -> "مشخص سرعة واستقرار الاتصال"
            "conn_sub" -> "تحقق من سلامة وجودة اتصالك بالإنترنت"
            "conn_status" -> "الحالة الحالية للشبكة"
            "conn_online" -> "متصل بالإنترنت"
            "conn_offline" -> "غير متصل بالإنترنت (أوفلاين)"
            "conn_network_type" -> "نوع الشبكة المتصلة"
            "conn_ping_btn" -> "ابدأ فحص البينج وزمن الاستجابة"
            "conn_pinging" -> "جاري التحقق وإرسال حزم البيانات..."
            "conn_results" -> "نتائج تشخيص الخوادم العالمية"
            "conn_excellent" -> "جودة اتصال ممتازة ورائعة!"
            "conn_average" -> "الاتصال مقبول، قد تجد بطئ طفيف"
            "conn_poor" -> "جودة الاتصال ضعيفة للغاية حالياً"
            
            else -> key
        }
    } else {
        when (key) {
            "app_title" -> "Aura Toolbox"
            "tab_device" -> "Device"
            "tab_zones" -> "Zones"
            "tab_notes" -> "Notes"
            "tab_breathe" -> "Breathe"
            "tab_pinger" -> "Pinger"
            
            // Device Screen
            "device_header" -> "System & Device Monitor"
            "device_sub" -> "Real-time, offline diagnostics for your device"
            "battery_level" -> "Battery Charge"
            "battery_status" -> "Battery Battery Status"
            "battery_charging" -> "Charging Now"
            "battery_plugged" -> "Plugged In"
            "battery_discharging" -> "Discharging"
            "battery_full" -> "Charged Fully"
            "battery_unknown" -> "Unknown Status"
            "device_info" -> "System Specifications"
            "sys_brand" -> "Manufacturer"
            "sys_model" -> "Device Model"
            "sys_os" -> "Android OS"
            "sys_sdk" -> "API SDK Level"
            "sys_hardware" -> "Hardware Chip"
            "sys_display" -> "Display resolution"
            
            // Zones Screen
            "zones_header" -> "Global Time Travel"
            "zones_sub" -> "Check and coordinate timezone differences instantly"
            "gmt_offset" -> "Time Travel Offset: %+d Hours"
            "city_london" -> "London"
            "city_cairo" -> "Cairo"
            "city_mecca" -> "Mecca"
            "city_tokyo" -> "Tokyo"
            "city_newyork" -> "New York"
            "time_travel_title" -> "Travel Coordinator"
            "time_standard" -> "Real Time"
            
            // Notes Screen
            "notes_header" -> "Secure Local Scratchpad"
            "notes_sub" -> "Your private sticky notes, saved strictly on device"
            "note_title" -> "Note Title"
            "note_content" -> "Type your quick note details here..."
            "note_add" -> "Save Note"
            "note_search" -> "Search keys..."
            "note_empty" -> "No thoughts left behind! Save your first sticky note."
            "note_deleted" -> "Note deleted successfully!"
            "note_added" -> "Note saved to device!"
            "note_copied" -> "Copied note text to Clipboard!"
            
            // Breathe Screen
            "breathe_header" -> "Breathe & Unwind Sanctuary"
            "breathe_sub" -> "Guided diaphragmatic breathing for stress relief"
            "breathe_mode" -> "Breathing Pattern"
            "breathe_mode_box" -> "Box Breathing (4s - 4s - 4s)"
            "breathe_mode_relax" -> "Deep Relax Breathing (4s - 7s - 8s)"
            "breathe_mode_equal" -> "Balanced Breathing (5s - 5s)"
            "breathe_state_inhale" -> "Inhale... Fill with energy"
            "breathe_state_hold" -> "Hold... Calm your soul"
            "breathe_state_exhale" -> "Exhale... Let go of fatigue"
            "breathe_start" -> "Begin Focus Exercise"
            "breathe_customizer" -> "Interactive visual audio visualizer with Canvas"
            "audio_wave" -> "Aesthetic Resonance Mode"
            
            // Connectivity Screen
            "conn_header" -> "Connectivity Pinger Diagnostics"
            "conn_sub" -> "Measure connection latency and DNS responsiveness"
            "conn_status" -> "Active Internet Status"
            "conn_online" -> "Device is Online"
            "conn_offline" -> "Device is Offline"
            "conn_network_type" -> "Active Band Type"
            "conn_ping_btn" -> "Execute Diagnostic Ping Test"
            "conn_pinging" -> "Sending packets to global nameservers..."
            "conn_results" -> "Global Server Latency Diagnostics"
            "conn_excellent" -> "Excellent connection standard!"
            "conn_average" -> "Average packet transfer speeds detected"
            "conn_poor" -> "Unstable packet speeds or offline"
            
            else -> key
        }
    }
}

// Represent sticky notes
data class QuickNote(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val content: String,
    val dateCreated: String,
    val colorIndex: Int = Random().nextInt(5)
)

val noteColors = listOf(
    Color(0xFFF7F2FA), // Bento Lavender/Purple
    Color(0xFFD8E2FF), // Bento Soft Blue
    Color(0xFFE2F3E7), // Bento Pastel Teal
    Color(0xFFFFFAEC), // Bento Soft Sand/Gold
    Color(0xFFFBECEE)  // Bento Pastel Blush/Pink
)

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun AuraToolboxApp(
    modifier: Modifier = Modifier
) {
    var isArabic by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableStateOf(0) }
    
    // Bento light gradient matching the [#D8E2FF] to [#FDFBFF] spec
    val mainGradient = Brush.verticalGradient(
        colors = listOf(
            BentoGradientStart,
            BentoBackground
        )
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(mainGradient)
            .safeDrawingPadding() // Ensures safe area insets for notches & gestures
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            
            // Bilingual Custom Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(BentoCardLight)
                            .border(1.dp, BentoBorder, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.SettingsSuggest,
                            contentDescription = "Aura Logo",
                            tint = BentoPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Column {
                        Text(
                            text = getTxt("app_title", isArabic),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = BentoTextDark,
                            fontFamily = FontFamily.SansSerif
                        )
                        Text(
                            text = if (isArabic) "البوابة الذكية لعمليات التطبيق" else "Pure client-side system tools",
                            style = MaterialTheme.typography.labelSmall,
                            color = BentoTextGray
                        )
                    }
                }

                // Smooth Language Toggle Pill
                Button(
                    onClick = { isArabic = !isArabic },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = BentoCardLight
                    ),
                    modifier = Modifier
                        .height(38.dp)
                        .border(1.dp, BentoBorder, RoundedCornerShape(20.dp))
                        .testTag("lang_toggle"),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Language,
                            contentDescription = "Language",
                            tint = BentoPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = if (isArabic) "English" else "العربية",
                            style = MaterialTheme.typography.labelMedium,
                            color = BentoTextDark,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            Divider(color = BentoBorder, thickness = 1.dp)

            // Dynamic Core Content based on active tab
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                // Crossfade animation between screens
                AnimatedContent(
                    targetState = selectedTab,
                    transitionSpec = {
                        fadeIn(animationSpec = tween(220)) with fadeOut(animationSpec = tween(220))
                    }
                ) { targetState ->
                    when (targetState) {
                        0 -> DeviceInfoScreen(isArabic = isArabic)
                        1 -> GlobalTimeTravellerScreen(isArabic = isArabic)
                        2 -> NotesScratchpadScreen(isArabic = isArabic)
                        3 -> AuraBreatheScreen(isArabic = isArabic)
                        4 -> ConnectionPingerScreen(isArabic = isArabic)
                    }
                }
            }

            Divider(color = BentoBorder, thickness = 1.dp)

            // Modern Bottom Navigation Row (M3 styling)
            NavigationBar(
                containerColor = Color.White,
                tonalElevation = 6.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(BorderStroke(1.dp, BentoBorder))
            ) {
                val tabs = listOf(
                    Triple(0, Icons.Filled.Monitor, "tab_device"),
                    Triple(1, Icons.Filled.AccessTime, "tab_zones"),
                    Triple(2, Icons.Filled.DriveFileRenameOutline, "tab_notes"),
                    Triple(3, Icons.Filled.Spa, "tab_breathe"),
                    Triple(4, Icons.Filled.NetworkCheck, "tab_pinger")
                )

                tabs.forEach { (index, icon, textKey) ->
                    val isSelected = selectedTab == index
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { selectedTab = index },
                        icon = {
                            Icon(
                                imageVector = icon,
                                contentDescription = getTxt(textKey, isArabic),
                                tint = if (isSelected) Color.White else BentoTextGray
                            )
                        },
                        label = {
                            Text(
                                text = getTxt(textKey, isArabic),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) BentoPrimary else BentoTextGray,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = BentoPrimary,
                            selectedIconColor = Color.White,
                            unselectedIconColor = BentoTextGray,
                            selectedTextColor = BentoPrimary,
                            unselectedTextColor = BentoTextGray
                        ),
                        modifier = Modifier.testTag("tab_item_$index")
                    )
                }
            }
        }
    }
}

// ==========================================
// SCREEN 0: DEVICE MONITOR
// ==========================================
@Composable
fun DeviceInfoScreen(isArabic: Boolean) {
    val context = LocalContext.current
    val displayDensity = LocalDensity.current.density.toInt()
    var batteryLevel by remember { mutableStateOf(100) }
    var batteryStatus by remember { mutableStateOf(BatteryManager.BATTERY_STATUS_UNKNOWN) }
    var batteryPlugged by remember { mutableStateOf(0) }

    // Broadcast receiver to register battery changes reactively
    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                if (level != -1 && scale != -1) {
                    batteryLevel = (level.toFloat() / scale.toFloat() * 100).toInt()
                }
                batteryStatus = intent.getIntExtra(BatteryManager.EXTRA_STATUS, BatteryManager.BATTERY_STATUS_UNKNOWN)
                batteryPlugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
            }
        }
        val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        context.registerReceiver(receiver, filter)
        onDispose {
            context.unregisterReceiver(receiver)
        }
    }

    // Interactive custom state animations
    val batteryProgress by animateFloatAsState(
        targetValue = batteryLevel / 100f,
        animationSpec = spring(stiffness = Spring.StiffnessLow)
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            ScreenHeader(
                title = getTxt("device_header", isArabic),
                subtitle = getTxt("device_sub", isArabic),
                icon = Icons.Filled.DeveloperBoard
            )
        }

        // Circular Battery Aura Progress Ring
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, BentoBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = getTxt("battery_level", isArabic),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = BentoTextDark
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${batteryLevel}%",
                            style = MaterialTheme.typography.headlineLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (batteryLevel > 20) BentoPrimary else Color(0xFFFF5252)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        // Status details
                        val statusText = when (batteryStatus) {
                            BatteryManager.BATTERY_STATUS_CHARGING -> getTxt("battery_charging", isArabic)
                            BatteryManager.BATTERY_STATUS_DISCHARGING -> getTxt("battery_discharging", isArabic)
                            BatteryManager.BATTERY_STATUS_FULL -> getTxt("battery_full", isArabic)
                            else -> getTxt("battery_unknown", isArabic)
                        }
                        
                        val plugIcon = if (batteryPlugged > 0) Icons.Filled.Power else Icons.Filled.BatteryAlert

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = plugIcon,
                                contentDescription = "Plug status",
                                tint = if (batteryPlugged > 0) BentoPrimary else BentoTextGray,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = statusText,
                                style = MaterialTheme.typography.bodyMedium,
                                color = BentoTextGray
                            )
                        }
                    }

                    // Rotating Neon Progress Canvas Ring
                    Box(
                        modifier = Modifier
                            .size(100.dp)
                            .padding(4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            // Track
                            drawCircle(
                                color = BentoCardLight,
                                style = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round)
                            )
                            // Progress
                            drawArc(
                                color = if (batteryLevel > 20) BentoPrimary else Color(0xFFFF5252),
                                startAngle = -90f,
                                sweepAngle = 360f * batteryProgress,
                                useCenter = false,
                                style = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round)
                            )
                        }
                        Icon(
                            imageVector = if (batteryStatus == BatteryManager.BATTERY_STATUS_CHARGING) Icons.Filled.ElectricBolt else Icons.Filled.BatteryChargingFull,
                            contentDescription = "Battery charge icon",
                            tint = if (batteryStatus == BatteryManager.BATTERY_STATUS_CHARGING) BentoPrimary else BentoTextDark,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }
            }
        }

        // System specifications Grid
        item {
            Text(
                text = getTxt("device_info", isArabic),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = BentoTextDark,
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }

        val details = listOf(
            Triple(getTxt("sys_brand", isArabic), Build.BRAND.replaceFirstChar { it.uppercase() }, Icons.Filled.Category),
            Triple(getTxt("sys_model", isArabic), Build.MODEL, Icons.Filled.PhoneAndroid),
            Triple(getTxt("sys_os", isArabic), "Android ${Build.VERSION.RELEASE}", Icons.Filled.Android),
            Triple(getTxt("sys_sdk", isArabic), "API ${Build.VERSION.SDK_INT}", Icons.Filled.Code),
            Triple(getTxt("sys_hardware", isArabic), Build.HARDWARE, Icons.Filled.Memory),
            Triple(
                getTxt("sys_display", isArabic),
                "Dense ${displayDensity}x Multi",
                Icons.Filled.AspectRatio
            )
        )

        items(details) { (title, subtitle, icon) ->
            DeviceInfoRow(title = title, value = subtitle, icon = icon)
        }
    }
}

@Composable
fun DeviceInfoRow(title: String, value: String, icon: ImageVector) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, BentoBorder),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(BentoCardLight),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = BentoPrimary,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium,
                    color = BentoTextGray
                )
                Text(
                    text = value,
                    style = MaterialTheme.typography.bodyMedium,
                    color = BentoTextDark,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}


// ==========================================
// SCREEN 1: GLOBAL TIME TRAVELLER SCREEN
// ==========================================
@Composable
fun GlobalTimeTravellerScreen(isArabic: Boolean) {
    var manualOffsetHours by remember { mutableStateOf(0) }
    
    // Periodically updating clock trigger
    var tickTrigger by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            tickTrigger = System.currentTimeMillis()
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            ScreenHeader(
                title = getTxt("zones_header", isArabic),
                subtitle = getTxt("zones_sub", isArabic),
                icon = Icons.Filled.Schedule
            )
        }

        // Time travel slider card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, BentoBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = getTxt("time_travel_title", isArabic),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = BentoTextDark
                        )
                        IconButton(
                            onClick = { manualOffsetHours = 0 },
                            colors = IconButtonDefaults.iconButtonColors(
                                containerColor = BentoCardLight
                            ),
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Restore,
                                contentDescription = "Reset time travel",
                                tint = BentoPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = getTxt("gmt_offset", isArabic).format(manualOffsetHours),
                        style = MaterialTheme.typography.bodyMedium,
                        color = BentoPrimary,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Slider(
                        value = manualOffsetHours.toFloat(),
                        onValueChange = { manualOffsetHours = it.toInt() },
                        valueRange = -12f..14f,
                        steps = 25,
                        colors = SliderDefaults.colors(
                            thumbColor = BentoPrimary,
                            activeTrackColor = BentoPrimary,
                            inactiveTrackColor = BentoCardLight
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("time_travel_slider")
                    )
                }
            }
        }

        item {
            Text(
                text = if (isArabic) "قارن التوقيت المباشر للمدن الكونية" else "Compare Live Cities Times",
                style = MaterialTheme.typography.titleSmall,
                color = BentoTextGray,
                fontWeight = FontWeight.Bold
            )
        }

        // Predefined key global cities with timezone calculations
        val cities = listOf(
            // CityName, raw gmt offset in hours, isArabic translation key
            Triple("London", 1, "city_london"),
            Triple("Cairo", 3, "city_cairo"), // Standard Summer/Winter or GMT+3
            Triple("Mecca", 3, "city_mecca"),
            Triple("Tokyo", 9, "city_tokyo"),
            Triple("New York", -4, "city_newyork")
        )

        items(cities) { (engName, baseGmtOffset, transKey) ->
            TimeZoneCompareRow(
                cityName = getTxt(transKey, isArabic),
                baseOffset = baseGmtOffset,
                manualTravelOffset = manualOffsetHours,
                trigger = tickTrigger,
                isArabic = isArabic
            )
        }
    }
}

@Composable
fun TimeZoneCompareRow(
    cityName: String,
    baseOffset: Int,
    manualTravelOffset: Int,
    trigger: Long, // Keep reading trigger so it recomposes
    isArabic: Boolean
) {
    // Calculate final calendar time based on offsets
    val targetTimeMillis = remember(trigger, manualTravelOffset) {
        val calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT"))
        calendar.add(Calendar.HOUR_OF_DAY, baseOffset + manualTravelOffset)
        calendar.time
    }

    val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
    val dateFormat = SimpleDateFormat("E, d LLL", Locale.getDefault())
    
    val hourOfDay = remember(targetTimeMillis) {
        val calendar = Calendar.getInstance()
        calendar.time = targetTimeMillis
        calendar.get(Calendar.HOUR_OF_DAY)
    }
    
    val isNightMode = hourOfDay < 6 || hourOfDay > 18

    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(
            1.dp, 
            if (manualTravelOffset != 0) BentoPrimary else BentoBorder
        ),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (isNightMode) Color(0xFFF0F4FF) else Color(0xFFFFFAEC)
                        )
                        .border(1.dp, BentoBorder, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isNightMode) Icons.Filled.NightsStay else Icons.Filled.WbCloudy,
                        contentDescription = "Day/Night Status",
                        tint = if (isNightMode) Color(0xFF3F51B5) else Color(0xFFFFB300),
                        modifier = Modifier.size(24.dp)
                    )
                }
                Column {
                    Text(
                        text = cityName,
                        style = MaterialTheme.typography.titleMedium,
                        color = BentoTextDark,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = dateFormat.format(targetTimeMillis),
                        style = MaterialTheme.typography.labelSmall,
                        color = BentoTextGray
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = timeFormat.format(targetTimeMillis),
                    style = MaterialTheme.typography.titleLarge,
                    color = if (manualTravelOffset != 0) BentoPrimary else BentoTextDark,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = if (manualTravelOffset != 0) getTxt("time_travel_title", isArabic) else getTxt("time_standard", isArabic),
                    style = MaterialTheme.typography.labelSmall,
                    color = if (manualTravelOffset != 0) BentoPrimary else BentoTextGray
                )
            }
        }
    }
}


// ==========================================
// SCREEN 2: SCRATCHPAD STICKY NOTES SCREEN
// ==========================================
@Composable
fun NotesScratchpadScreen(isArabic: Boolean) {
    val context = LocalContext.current
    val clip = LocalClipboardManager.current
    val sp = remember { context.getSharedPreferences("aura_toolbox_v1", Context.MODE_PRIVATE) }
    
    var noteTitle by remember { mutableStateOf("") }
    var noteContent by remember { mutableStateOf("") }
    var searchQuery by remember { mutableStateOf("") }
    
    // Loaded list of local notes
    var notesList by remember { mutableStateOf(listOf<QuickNote>()) }

    // Load helper
    fun loadNotes() {
        val serialized = sp.getString("scratchpad_notes", "") ?: ""
        if (serialized.isEmpty()) {
            notesList = emptyList()
            return
        }
        val array = serialized.split("%%%")
        val parsed = array.mapNotNull { item ->
            val sections = item.split("|||")
            if (sections.size >= 4) {
                QuickNote(
                    id = sections[0],
                    title = sections[1],
                    content = sections[2],
                    dateCreated = sections[3],
                    colorIndex = sections.getOrNull(4)?.toIntOrNull() ?: 0
                )
            } else null
        }
        notesList = parsed
    }

    // Save helper
    fun saveNotes(newList: List<QuickNote>) {
        val serialized = newList.joinToString("%%%") { note ->
            "${note.id}|||${note.title}|||${note.content}|||${note.dateCreated}|||${note.colorIndex}"
        }
        sp.edit().putString("scratchpad_notes", serialized).apply()
        loadNotes()
    }

    // Load notes once initially
    LaunchedEffect(Unit) {
        loadNotes()
    }

    val filteredNotes = remember(searchQuery, notesList) {
        if (searchQuery.trim().isEmpty()) {
            notesList
        } else {
            notesList.filter {
                it.title.contains(searchQuery, ignoreCase = true) || 
                it.content.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            ScreenHeader(
                title = getTxt("notes_header", isArabic),
                subtitle = getTxt("notes_sub", isArabic),
                icon = Icons.Filled.DriveFileRenameOutline
            )
        }

        // Fast Post note form
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, BentoBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    TextField(
                        value = noteTitle,
                        onValueChange = { noteTitle = it },
                        placeholder = { Text(getTxt("note_title", isArabic), color = BentoTextGray) },
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFFF0F4FF),
                            unfocusedContainerColor = Color(0xFFF5F5F5),
                            disabledContainerColor = Color(0xFFF5F5F5),
                            focusedTextColor = BentoTextDark,
                            unfocusedTextColor = BentoTextDark,
                            focusedIndicatorColor = BentoPrimary,
                            unfocusedIndicatorColor = Color.Transparent
                        ),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().testTag("note_title_input")
                    )

                    TextField(
                        value = noteContent,
                        onValueChange = { noteContent = it },
                        placeholder = { Text(getTxt("note_content", isArabic), color = BentoTextGray) },
                        maxLines = 4,
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFFF0F4FF),
                            unfocusedContainerColor = Color(0xFFF5F5F5),
                            disabledContainerColor = Color(0xFFF5F5F5),
                            focusedTextColor = BentoTextDark,
                            unfocusedTextColor = BentoTextDark,
                            focusedIndicatorColor = BentoPrimary,
                            unfocusedIndicatorColor = Color.Transparent
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(90.dp)
                            .testTag("note_content_input")
                    )

                    Button(
                        onClick = {
                            if (noteTitle.trim().isEmpty() || noteContent.trim().isEmpty()) {
                                Toast.makeText(context, if (isArabic) "يرجى ملء جميع الحقول أولاً" else "Please fill note details!", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            val newNote = QuickNote(
                                title = noteTitle,
                                content = noteContent,
                                dateCreated = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date())
                            )
                            val updated = notesList.toMutableList().apply { add(0, newNote) }
                            saveNotes(updated)
                            noteTitle = ""
                            noteContent = ""
                            Toast.makeText(context, getTxt("note_added", isArabic), Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = BentoPrimary,
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("save_note_btn"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(imageVector = Icons.Filled.Save, contentDescription = "Save icon")
                            Text(
                                text = getTxt("note_add", isArabic),
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
            }
        }

        // Search Field
        item {
            TextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text(getTxt("note_search", isArabic), color = BentoTextGray) },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Search", tint = BentoTextGray) },
                singleLine = true,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    focusedTextColor = BentoTextDark,
                    unfocusedTextColor = BentoTextDark,
                    focusedIndicatorColor = BentoPrimary,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BentoBorder, RoundedCornerShape(12.dp))
                    .testTag("search_notes")
            )
        }

        // Grid/List representation of Saved notes
        if (filteredNotes.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.PostAdd,
                            contentDescription = "Empty",
                            tint = Color.Gray.copy(alpha = 0.5f),
                            modifier = Modifier.size(56.dp)
                        )
                        Text(
                            text = getTxt("note_empty", isArabic),
                            color = Color.Gray,
                            style = MaterialTheme.typography.bodyMedium,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 24.dp)
                        )
                    }
                }
            }
        } else {
            items(filteredNotes, key = { it.id }) { note ->
                val auraBgColor = noteColors.getOrElse(note.colorIndex) { Color(0xFFF7F2FA) }
                
                Card(
                    colors = CardDefaults.cardColors(containerColor = auraBgColor),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, BentoBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = note.title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = BentoTextDark
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                // Copy capability
                                IconButton(
                                    onClick = {
                                        clip.setText(AnnotatedString("${note.title}\n\n${note.content}"))
                                        Toast.makeText(context, getTxt("note_copied", isArabic), Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.ContentCopy,
                                        contentDescription = "Copy",
                                        tint = BentoTextGray,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                // Delete note button
                                IconButton(
                                    onClick = {
                                        val updated = notesList.toMutableList().apply { removeAll { it.id == note.id } }
                                        saveNotes(updated)
                                        Toast.makeText(context, getTxt("note_deleted", isArabic), Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.DeleteOutline,
                                        contentDescription = "Delete",
                                        tint = Color(0xFFFF5252),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(6.dp))
                        
                        Text(
                            text = note.content,
                            style = MaterialTheme.typography.bodyMedium,
                            color = BentoTextGray
                        )
                        
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color.White.copy(alpha = 0.5f))
                                    .border(1.dp, BentoBorder, RoundedCornerShape(6.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = note.dateCreated,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = BentoTextDark,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Icon(
                                imageVector = Icons.Filled.OfflinePin,
                                contentDescription = "Stored locally",
                                tint = BentoPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}


// ==========================================
// SCREEN 3: FOCUS BREATHE SCREEN (MINDFULNESS)
// ==========================================
@OptIn(ExperimentalAnimationApi::class)
@Composable
fun AuraBreatheScreen(isArabic: Boolean) {
    var isBreathingActive by remember { mutableStateOf(false) }
    var currentBreathingMode by remember { mutableStateOf(0) } // 0: Box, 1: 4-7-8, 2: 5-5
    
    // Cycle variables
    var secondsRemainingInPhase by remember { mutableStateOf(4) }
    var currentPhase by remember { mutableStateOf(0) } // 0: Inhale, 1: Hold, 2: Exhale

    // Coroutine to manager relaxation ticker cycles
    LaunchedEffect(isBreathingActive, currentBreathingMode, currentPhase) {
        if (!isBreathingActive) return@LaunchedEffect
        
        val phaseDuration = when (currentBreathingMode) {
            0 -> 4 // Box (Inhale 4, Hold 4, Exhale 4)
            1 -> when (currentPhase) { // Relax 4-7-8
                0 -> 4 // Inhale
                1 -> 7 // Hold
                else -> 8 // Exhale
            }
            else -> 5 // Balanced 5-5 (Inhale 5, Exhale 5)
        }
        
        secondsRemainingInPhase = phaseDuration
        while (secondsRemainingInPhase > 0) {
            delay(1000)
            secondsRemainingInPhase--
        }
        
        // Transition phases
        currentPhase = when (currentBreathingMode) {
            2 -> if (currentPhase == 0) 2 else 0 // Balanced only has inhale/exhale
            else -> (currentPhase + 1) % 3
        }
    }

    // Canvas pulsation floating ratio
    val transition = rememberInfiniteTransition()
    val pulsateFactor by transition.animateFloat(
        initialValue = 0.82f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(2800, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        )
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            ScreenHeader(
                title = getTxt("breathe_header", isArabic),
                subtitle = getTxt("breathe_sub", isArabic),
                icon = Icons.Filled.Spa
            )
        }

        // Program Selectors Tab Selector
        item {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = getTxt("breathe_mode", isArabic),
                    style = MaterialTheme.typography.titleSmall,
                    color = BentoTextGray,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.Start)
                )

                val modes = listOf(
                    Pair(0, getTxt("breathe_mode_box", isArabic)),
                    Pair(1, getTxt("breathe_mode_relax", isArabic)),
                    Pair(2, getTxt("breathe_mode_equal", isArabic))
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    modes.forEach { (index, title) ->
                        val isSel = currentBreathingMode == index
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSel) BentoPrimary else Color.White
                            ),
                            shape = RoundedCornerShape(12.dp),
                            border = if (!isSel) BorderStroke(1.dp, BentoBorder) else null,
                            onClick = {
                                if (!isBreathingActive) {
                                    currentBreathingMode = index
                                    currentPhase = 0
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(56.dp)
                        ) {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = title,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isSel) Color.White else BentoTextDark,
                                    textAlign = TextAlign.Center,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Interactive Canvas Breathing Ring
        item {
            Box(
                modifier = Modifier
                    .size(240.dp)
                    .padding(16.dp)
                    .drawBehind {
                        // Ambient radial shadow glows to prevent dead graphics
                        drawCircle(
                            color = BentoPrimary.copy(alpha = 0.04f * pulsateFactor),
                            radius = size.minDimension / 1.5f
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                val scaleFactor = if (isBreathingActive) {
                    when (currentPhase) {
                        0 -> 0.85f + (0.4f * ((4 - secondsRemainingInPhase).toFloat() / 4f).coerceIn(0f, 1f)) // Growing
                        1 -> 1.25f // Holding
                        else -> 1.25f - (0.4f * ((4 - secondsRemainingInPhase).toFloat() / 4f).coerceIn(0f, 1f)) // Shrinking
                    }
                } else pulsateFactor

                // Dynamic Canvas Circle drawing
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .scale(scaleFactor)
                ) {
                    // Soft glowing multi-gradients
                    val brush = Brush.radialGradient(
                        colors = listOf(
                            BentoPrimary.copy(alpha = 0.15f),
                            Color.White.copy(alpha = 0.0f)
                        ),
                        center = center,
                        radius = size.width / 2
                    )
                    drawCircle(brush = brush)

                    // Outer futuristic neon stroke lines
                    drawCircle(
                        color = if (isBreathingActive && currentPhase == 1) BentoPrimary.copy(alpha = 0.5f) else BentoPrimary,
                        style = Stroke(
                            width = 4.dp.toPx(),
                            cap = StrokeCap.Round
                        ),
                        radius = size.width / 2.4f
                    )
                }

                // Inner Phase countdown details
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    AnimatedContent(
                        targetState = currentPhase,
                        transitionSpec = { slideInVertically { it / 2 } + fadeIn() with slideOutVertically { -it / 2 } + fadeOut() }
                    ) { phase ->
                        val phaseLabel = if (isBreathingActive) {
                            when (phase) {
                                0 -> getTxt("breathe_state_inhale", isArabic)
                                1 -> getTxt("breathe_state_hold", isArabic)
                                else -> getTxt("breathe_state_exhale", isArabic)
                            }
                        } else (if (isArabic) "جاهز للاسترخاء" else "Ready to Focus")
                        
                        Text(
                            text = phaseLabel,
                            style = MaterialTheme.typography.titleSmall,
                            color = BentoTextDark,
                            textAlign = TextAlign.Center,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isBreathingActive) "$secondsRemainingInPhase" else "∞",
                        style = MaterialTheme.typography.displayMedium,
                        fontWeight = FontWeight.Black,
                        color = BentoPrimary
                    )
                }
            }
        }

        // Active control state triggers
        item {
            Button(
                onClick = {
                    isBreathingActive = !isBreathingActive
                    if (!isBreathingActive) {
                        currentPhase = 0
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isBreathingActive) Color(0xFFFF5252) else BentoPrimary,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("breathe_control_btn")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = if (isBreathingActive) Icons.Filled.StopCircle else Icons.Filled.PlayCircle,
                        contentDescription = "Trigger button"
                    )
                    Text(
                        text = if (isBreathingActive) (if (isArabic) "إيقاف التمرين" else "Stop Exercise") else getTxt("breathe_start", isArabic),
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
            }
        }

        // Live bouncing bar simulators that moves actively if breathing to provide excellent interactive visuals
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, BentoBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = getTxt("breathe_customizer", isArabic),
                        style = MaterialTheme.typography.labelMedium,
                        color = BentoTextGray,
                        textAlign = TextAlign.Center
                    )
                    
                    // Drawing audio-like diagnostic waves on canvas
                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(30.dp)
                    ) {
                        val barCount = 15
                        val barWidth = 8.dp.toPx()
                        val spacing = 6.dp.toPx()
                        val totalWidth = barCount * barWidth + (barCount - 1) * spacing
                        val startX = (size.width - totalWidth) / 2

                        for (i in 0 until barCount) {
                            val activeSin = sin((System.currentTimeMillis() / 150.0) + i * 0.51).toFloat()
                            val rawMultiplier = if (isBreathingActive) (if (currentPhase == 0) 0.8f else 0.3f) else 0.15f
                            val h = size.height * (0.3f + (activeSin + 1f) / 2f * rawMultiplier)
                            
                            val x = startX + i * (barWidth + spacing)
                            val y = (size.height - h) / 2

                            drawRoundRect(
                                color = BentoPrimary.copy(alpha = 0.5f + (activeSin + 1f) / 4f),
                                topLeft = Offset(x, y),
                                size = androidx.compose.ui.geometry.Size(barWidth, h),
                                cornerRadius = androidx.compose.ui.geometry.CornerRadius(4.dp.toPx(), 4.dp.toPx())
                            )
                        }
                    }
                }
            }
        }
    }
}


// ==========================================
// SCREEN 4: CONNECTIVITY DIAGNOSTICS PINGER
// ==========================================
@Composable
fun ConnectionPingerScreen(isArabic: Boolean) {
    val context = LocalContext.current
    var isCheckingActive by remember { mutableStateOf(false) }
    var pingResults by remember { mutableStateOf<Map<String, String>?>(null) }
    
    // Check actual connectivity specs via standard frameworks
    val connectivityManager = remember {
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    }
    
    var localSubscribedState by remember { mutableStateOf("Offline") }
    var isDeviceOnline by remember { mutableStateOf(false) }

    fun checkDeviceLiveNetwork() {
        val activeNetwork = connectivityManager.activeNetwork
        val caps = connectivityManager.getNetworkCapabilities(activeNetwork)
        if (caps != null) {
            isDeviceOnline = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            localSubscribedState = when {
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi Wireless"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Cellular Mobile"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet Cable"
                else -> "Standard Link"
            }
        } else {
            isDeviceOnline = false
            localSubscribedState = "Disconnected"
        }
    }

    LaunchedEffect(Unit) {
        checkDeviceLiveNetwork()
    }

    val coroutineScope = rememberCoroutineScope()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            ScreenHeader(
                title = getTxt("conn_header", isArabic),
                subtitle = getTxt("conn_sub", isArabic),
                icon = Icons.Filled.NetworkCheck
            )
        }

        // Network Status card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(
                    1.dp, 
                    if (isDeviceOnline) BentoPrimary.copy(alpha = 0.5f) else Color(0xFFFF5252).copy(alpha = 0.5f)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = getTxt("conn_status", isArabic),
                            style = MaterialTheme.typography.labelMedium,
                            color = BentoTextGray
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isDeviceOnline) getTxt("conn_online", isArabic) else getTxt("conn_offline", isArabic),
                            style = MaterialTheme.typography.titleLarge,
                            color = if (isDeviceOnline) Color(0xFF00875A) else Color(0xFFFF5252),
                            fontWeight = FontWeight.ExtraBold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "${getTxt("conn_network_type", isArabic)}: $localSubscribedState",
                            style = MaterialTheme.typography.bodySmall,
                            color = BentoTextGray
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (isDeviceOnline) Color(0xFFE2F3E7) else Color(0xFFFBECEE)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isDeviceOnline) Icons.Filled.Wifi else Icons.Filled.WifiOff,
                            contentDescription = "Status icon",
                            tint = if (isDeviceOnline) Color(0xFF00875A) else Color(0xFFFF5252),
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
            }
        }

        // Operational ping buttons
        item {
            Button(
                onClick = {
                    checkDeviceLiveNetwork()
                    coroutineScope.launch {
                        isCheckingActive = true
                        pingResults = null
                        // Mock interactive test latency diagnostic sequence
                        delay(1200)
                        pingResults = if (isDeviceOnline) {
                            mapOf(
                                "Google Public DNS (8.8.8.8)" to "${Random().nextInt(35) + 12} ms",
                                "Cloudflare Fast CDN (1.1.1.1)" to "${Random().nextInt(28) + 8} ms",
                                "GitHub Root Server (140.82.121.4)" to "${Random().nextInt(80) + 40} ms",
                                "AI Studio Cloud Terminal" to "${Random().nextInt(90) + 65} ms"
                            )
                        } else {
                            mapOf(
                                "Google Public DNS (8.8.8.8)" to "Timed Out (Offline)",
                                "Cloudflare Fast CDN (1.1.1.1)" to "Timed Out (Offline)",
                                "GitHub Root Server (140.82.121.4)" to "Timed Out (Offline)",
                                "AI Studio Cloud Terminal" to "Timed Out (Offline)"
                            )
                        }
                        isCheckingActive = false
                    }
                },
                enabled = !isCheckingActive,
                colors = ButtonDefaults.buttonColors(
                    containerColor = BentoPrimary,
                    contentColor = Color.White,
                    disabledContainerColor = BentoCardLight
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("ping_test_btn")
            ) {
                if (isCheckingActive) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                        Text(text = getTxt("conn_pinging", isArabic), fontWeight = FontWeight.Bold)
                    }
                } else {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(imageVector = Icons.Filled.SportsScore, contentDescription = "Ping icon")
                        Text(text = getTxt("conn_ping_btn", isArabic), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Diagnostic nameservers latency lists
        pingResults?.let { results ->
            item {
                Text(
                    text = getTxt("conn_results", isArabic),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = BentoTextDark,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            items(results.toList()) { (endpoint, delayVal) ->
                val isTimedOut = delayVal.contains("Timed")
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, BentoBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = endpoint, style = MaterialTheme.typography.bodyMedium, color = BentoTextDark)
                            Text(text = "ICMP Echo Requests", style = MaterialTheme.typography.labelSmall, color = BentoTextGray)
                        }
                        Text(
                            text = delayVal,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (isTimedOut) Color(0xFFFF5252) else Color(0xFF00875A),
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            // Summary recommendation
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isDeviceOnline) Color(0xFFE2F3E7) else Color(0xFFFBECEE)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(
                        1.dp,
                        if (isDeviceOnline) Color(0xFF00875A).copy(alpha = 0.2f) else Color(0xFFFF5252).copy(alpha = 0.2f)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isDeviceOnline) Icons.Filled.CheckCircle else Icons.Filled.Error,
                            contentDescription = "Analysis info",
                            tint = if (isDeviceOnline) Color(0xFF00875A) else Color(0xFFFF5252)
                        )
                        Text(
                            text = if (isDeviceOnline) getTxt("conn_excellent", isArabic) else getTxt("conn_poor", isArabic),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isDeviceOnline) Color(0xFF00875A) else Color(0xFFFF5252)
                        )
                    }
                }
            }
        }
    }
}


// ==========================================
// REUSABLE HELPER VIEW: CLEAN SECTION HEADERS
// ==========================================
@Composable
fun ScreenHeader(
    title: String,
    subtitle: String,
    icon: ImageVector
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(BentoPrimary.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = BentoPrimary,
                modifier = Modifier.size(26.dp)
            )
        }
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.ExtraBold,
                color = BentoTextDark
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = BentoTextGray
            )
        }
    }
}

