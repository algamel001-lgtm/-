package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

import androidx.compose.ui.graphics.Color

private val DarkColorScheme =
  darkColorScheme(
    primary = BentoPrimary,
    secondary = BentoCardMedium,
    tertiary = BentoCardPurple,
    background = BentoBackground,
    surface = Color.White,
    onPrimary = Color.White,
    onBackground = BentoTextDark,
    onSurface = BentoTextDark,
    outline = BentoBorder
  )

private val LightColorScheme =
  lightColorScheme(
    primary = BentoPrimary,
    secondary = BentoCardMedium,
    tertiary = BentoCardPurple,
    background = BentoBackground,
    surface = Color.White,
    onPrimary = Color.White,
    onBackground = BentoTextDark,
    onSurface = BentoTextDark,
    outline = BentoBorder
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Disable dynamic colors to enforce the strict Bento premium color branding requested
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme


  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
