package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Bento Grid Design Theme Palettes
val BentoPrimary = Color(0xFF005AC1)
val BentoBackground = Color(0xFFFDFBFF)
val BentoGradientStart = Color(0xFFD8E2FF)
val BentoCardMedium = Color(0xFFD8E2FF)
val BentoCardLight = Color(0xFFE1E2EC)
val BentoCardPurple = Color(0xFFF7F2FA)
val BentoBorder = Color(0xFFC4C6D0)
val BentoTextDark = Color(0xFF001A41)
val BentoTextGray = Color(0xFF44474E)
val BentoTextAccent = Color(0xFF1D1B20)

